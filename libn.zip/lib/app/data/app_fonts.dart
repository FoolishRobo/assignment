import 'dart:core';



class AppFonts{
  static String ns100 = "NotoSans-Thin";
  static String ns200 = 'NotoSans-ExtraLight';
  static String ns300 = 'NotoSans-Light';
  static String ns500 = 'NotoSans-Medium';
  static String ns400 = 'NotoSans-Regular';
  static String ns600 = 'NotoSans-Bold-SemiBold';
  static String ns700 = 'NotoSans-Bold';
  static String ns800 = 'NotoSans-ExtraBold';
  static String ns900 = 'NotoSans-Black';

}