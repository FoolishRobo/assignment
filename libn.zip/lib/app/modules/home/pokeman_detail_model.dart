class PokemanDetais {
  String name;
  String image;
  List types;
  List base_stats;
  int height;
  int weight;
  // int hp;
  // int attack;
  // int defense;
  // int s_defense;
  // int s_attack;
  // int speed;
  // int average;

  PokemanDetais({
    required this.name,
    required this.image,
    required this.types,
    required this.height,
    required this.weight,
    required this.base_stats,
    // required this.hp,
    // required this.attack,
    // required this.defense,
    // required this.s_attack,
    // required this.s_defense,
    // required this.average,
    // required this.speed,
  });
  factory PokemanDetais.fromJson(Map<String, dynamic> json) {
    return PokemanDetais(
      name: json['name'],
      image: json['sprites']['other']['official-artwork']['front_default'],
      types: json['types'],
      base_stats: json['stats'],
      height: json['height'],
      weight: json['weight'],
      // hp: null,
      // attack: null,
      // defense: null,
      // s_attack: null,
      // s_defense: null,
      // average: null,
      // speed: null,
    );
  }
}

class TypeDetail {
  final String name;
  final String url;

  TypeDetail({required this.name, required this.url});

  factory TypeDetail.fromJson(Map<String, dynamic> json) {
    return TypeDetail(
      name: json['name'],
      url: json['url'],
    );
  }
}

class TypeSlot {
  final int slot;
  final TypeDetail type;

  TypeSlot({required this.slot, required this.type});

  factory TypeSlot.fromJson(Map<String, dynamic> json) {
    return TypeSlot(
      slot: json['slot'],
      type: TypeDetail.fromJson(json['type']),
    );
  }
}