
import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../../../data/api_services.dart';
import '../controllers/home_controller.dart';
import '../pokeman_detail_model.dart';
import 'detailsview_view.dart';

class HomeView extends GetView<HomeController> {
  HomeView({Key? key}) : super(key: key);
  final HomeController controller = Get.find<HomeController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffE8E8E8),
      appBar: AppBar(
        title: const Text('HomeView'),
        centerTitle: true,
      ),
      body: Obx(() => controller.isLoading.value == true
          ? CircularProgressIndicator()
          : GridView.builder(
              padding: EdgeInsets.only(top: 16, left: 12, right: 12),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  mainAxisExtent: 186,
                  crossAxisCount: 3,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 12),
              itemBuilder: (context, index) {
                final pokemon = controller.pokemons[index];
                return FutureBuilder(
                    future: ApiService.fetchPokemon(pokemon.name),
                    builder: (ctx, snap) {
                      if (snap.hasData) {
                        PokemanDetais pokidetails = snap.data!;

                        var list = pokidetails.types;
                        return GestureDetector(
                          onTap: (){
                            Get.to(()=> DetailsviewView(),arguments: [pokidetails,list[0]['type']['name'] == 'fire'
                                ? Color(0xffFDF1F1)
                                : list[0]['type']['name'] == 'grass'
                                ? Color(0xffF3F9EF)
                                : list[0]['type']['name'] == 'water'
                                ? Color(0xffF3F9FE)
                                : Colors.black26,controller.formatNumberWithLeadingZeros(
                                        index + 1, 3)],);
                          },
                          child: Container(
                            color: Colors.white,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  child: Container(
                                    color: list[0]['type']['name'] == 'fire'
                                        ? Color(0xffFDF1F1)
                                        : list[0]['type']['name'] == 'grass'
                                            ? Color(0xffF3F9EF)
                                            : list[0]['type']['name'] == 'water'
                                                ? Color(0xffF3F9FE)
                                                : Colors.black26,
                                    height: 104,
                                    width: double.infinity,
                                    alignment: Alignment.center,
                                    child: Image.network(
                                      fit: BoxFit.cover,
                                      pokidetails.image,
                                      alignment: Alignment.center,
                                    ),
                                  ),
                                ),
                                Text("#" +
                                    controller.formatNumberWithLeadingZeros(
                                        index + 1, 3)),
                                Text(controller
                                    .capitalizeFirstLetter(pokidetails.name)),
                                Row(
                                  children: List.generate(
                                      list.length,
                                      (v) => Text(controller
                                              .capitalizeFirstLetter(
                                                  list[v]['type']['name']) +
                                          "${v == 0 && list.length > 1 ? "," : ""}" +
                                          ' ')),
                                ),
                              ],
                            ),
                          ),
                        );
                      } else {
                        return SizedBox();
                      }
                    });
              },
              itemCount: controller.pokemons.length,
            )),
    );
  }
}
