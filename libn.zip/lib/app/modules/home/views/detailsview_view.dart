import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../controllers/home_controller.dart';
import '../pokeman_detail_model.dart';

class DetailsviewView extends GetView {
   DetailsviewView({Key? key}) : super(key: key);
   final HomeController controller = Get.find<HomeController>();
  @override
  Widget build(BuildContext context) {
    PokemanDetais pokidetails = Get.arguments[0];
    print(pokidetails);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Get.arguments[1],
        leading: IconButton(
          onPressed: () {
            Get.back();
          },
          icon: Icon(Icons.arrow_back_ios),
        ),
      ),
      body: Column(
        children: [

          Container(
            height: 200,
            width: double.infinity,
            child: Stack(
              children: [
                Align(alignment: Alignment.topLeft,child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(controller.capitalizeFirstLetter(pokidetails.name)),
                      Row(
                                  children: List.generate(
                                      pokidetails.types.length,
                                      (v) => Text(controller
                                              .capitalizeFirstLetter(
                                                  pokidetails.types[v]['type']['name']) +
                                          "${v == 0 && pokidetails.types.length > 1 ? "," : ""}" +
                                          ' ')),
                                ),
                    Spacer(),
                    Text('#'+Get.arguments[2])
                  ],
                ),),
                Positioned(
                  bottom: -16,
                  right: -20,
                  child: Image.asset(
                    'assets/images/Vector.png',
                    height: 176,
                    width: 176,
                  ),
                ),
                Positioned(
                  bottom: 0,
                  right: 16,
                  child: Image.network(
                    pokidetails.image,
                    height: 125,
                    width: 136,
                  ),
                )
              ],
            ),
            color: Get.arguments[1],
          ),
          Container(height: 78,color: Colors.white,child: Row(children: [
            Column(children: [
              Text("Height"),
              Text(pokidetails.height.toString())
            ],),
             Column(children: [
              Text("Weight"),
              Text(pokidetails.weight.toString())
            ],),
             Column(children: [
              Text("BMI"),
              Text('${(pokidetails.weight/((pokidetails.height) * pokidetails.height)).truncate()}')
            ],),
          ],),)
        ],
      ),
    );
  }
}
